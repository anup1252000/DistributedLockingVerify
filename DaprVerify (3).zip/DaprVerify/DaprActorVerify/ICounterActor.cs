﻿using Dapr.Actors;

namespace DaprActorVerify
{
    public interface ICounterActor:IActor
    {
        Task<int> AddCountAsync(CancellationToken cancellationToken=default);
        Task<int> GetCountAsync(CancellationToken cancellationToken = default);
    }
}

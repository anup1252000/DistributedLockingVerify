﻿using Dapr;
using Dapr.Client.Autogen.Grpc.v1;
using Microsoft.AspNetCore.Mvc;

namespace DaprVerify.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SubscribeController : ControllerBase
    {
        [Topic("azure-servicebus-pubsub", "ganeshparvati")]
        [HttpPost("myqueue")]
        public IActionResult SubscribeToQueue([FromBody] string message)
        {
          
            // Process the message
            Console.WriteLine($"Received message: {message}");
            return Ok();
        }

        public class MyMessage
        {
            public string Content { get; set; }
        }

        [HttpGet]
        public IActionResult GetSubscriptions()
        {
            var subscriptions = new[]
            {
                new { pubsubname = "azure-servicebus-pubsub", topic = "myqueue", route = "Subscribe/myqueue" }
            };
            return new JsonResult(subscriptions);
        }
    }
}

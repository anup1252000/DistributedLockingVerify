var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers().AddDapr();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
builder.Services.AddDaprClient(); // Add this line to use DaprClient


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.UseCloudEvents(); // Add this line to use Dapr's CloudEvents

app.MapControllers();
app.MapSubscribeHandler(); // Add this line to map Dapr subscribe handler

app.Run();
